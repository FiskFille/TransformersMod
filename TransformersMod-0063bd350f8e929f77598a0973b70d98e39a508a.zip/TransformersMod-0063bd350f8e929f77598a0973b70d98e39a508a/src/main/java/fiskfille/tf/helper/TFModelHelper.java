package fiskfille.tf.helper;

import net.minecraft.client.model.ModelBiped;

public class TFModelHelper
{
	public static ModelBiped modelBipedMain = new ModelBiped();
}
