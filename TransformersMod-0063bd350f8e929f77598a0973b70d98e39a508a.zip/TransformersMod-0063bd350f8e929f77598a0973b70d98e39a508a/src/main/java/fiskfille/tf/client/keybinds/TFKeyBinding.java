package fiskfille.tf.client.keybinds;

import net.minecraft.client.settings.KeyBinding;

public class TFKeyBinding extends KeyBinding
{
	public TFKeyBinding(String name, int key)
	{
		super(name, key, "Transformers");
	}
}
