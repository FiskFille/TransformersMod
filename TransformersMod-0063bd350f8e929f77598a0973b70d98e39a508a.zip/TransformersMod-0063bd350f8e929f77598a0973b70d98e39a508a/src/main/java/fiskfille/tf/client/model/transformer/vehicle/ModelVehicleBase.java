package fiskfille.tf.client.model.transformer.vehicle;

import fiskfille.tf.client.model.transformer.ModelTransformer;

public class ModelVehicleBase extends ModelTransformer.Base
{
	public void render() {}
}