package fiskfille.tf.common.item;

public interface IDisplayPillarItem
{

}