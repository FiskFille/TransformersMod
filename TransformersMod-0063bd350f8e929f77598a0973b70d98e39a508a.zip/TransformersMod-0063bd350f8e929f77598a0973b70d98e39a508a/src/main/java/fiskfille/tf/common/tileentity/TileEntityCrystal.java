package fiskfille.tf.common.tileentity;

import net.minecraft.tileentity.TileEntity;

public class TileEntityCrystal extends TileEntity{

}
