package fiskfille.tf.donator;

public class Donator
{
    public String uuid;
    public String money;
}
